import { anything, mock, verify, instance } from "ts-mockito";
import { ServerFacade } from "../../src/net/ServerFacade";
import { GetFollowersCountRequest, GetUserRequest, RegisterRequest } from "tweeter-shared/src/model/net/Request";
import { AuthToken } from "tweeter-shared/src/model/domain/AuthToken";
import { User } from "tweeter-shared/src/model/domain/User";

describe("ServerFacade", () => {
  let mockServerFacade: ServerFacade;

  beforeEach(() => {
    mockServerFacade = mock(ServerFacade);
  });

  it("registers a user", async () => {
    const request = new RegisterRequest("bill", "Stevens", "@BillyBoi", "a22ffododod", "");
    await instance(mockServerFacade).register(request);
    verify(mockServerFacade.register(request)).once();
  });

  it("gets users", async () => {
    const request = new GetUserRequest("ohWow", new AuthToken("a456699", Date.now()));
    await instance(mockServerFacade).getUser(request);
    verify(mockServerFacade.getUser(request)).once();
  });

  it("gets a number of followers", async () => {
    const request = new GetFollowersCountRequest(new AuthToken("a456699", Date.now()), new User("bill", "Stevens", "@BillyBoi", ""));
    await instance(mockServerFacade).getFollowersCount(request);
    verify(mockServerFacade.getFollowersCount(request)).once();
  });
});
