import { mock, verify, instance } from "ts-mockito";
import { StatusService } from "../../src//model/service/StatusService"
import { User } from "tweeter-shared/src/model/domain/User";
import { AuthToken } from "tweeter-shared/src/model/domain/AuthToken";

describe("StatusService", () => {
  let mockStatusService: StatusService;

  beforeEach(() => {
    mockStatusService = mock(StatusService);
  });

  it("gets story items", async () => {
    let value = await instance(mockStatusService).loadMoreStoryItems(new AuthToken("a456699", Date.now()), new User("bill", "Stevens", "@BillyBoi", ""), 1, null)
    
    expect(value).not.toBeNull();
  });
});
